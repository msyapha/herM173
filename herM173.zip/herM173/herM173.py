
         ######################GLOBAL M173####################
         # herM173 the she  tool for networks scan of        #
         # ports & domains                                   #
         # developer :mustapha blaziz (m173)                 #
         # contact:blazizm173@gmail.com                      # 
         #####################################################
         
print("   _                _     _    _ _  ______  _______            ")
print("  | |              | \ _ / |  /   ||____  ||____   )           ") 
print("  | |__   ___ _ __ |       | / /\ |    / /     /  /            ")
print("  |  _ \ / _ \ '__|| '\_/' ||_/ | |   / /     (  \             ")
print("  | || ||  __/ |   | |   | |    | |  / /    ___\  )            ")
print("  |_||_| \___|_|   |_|   |_|    |_| /_/    |______/            ")
print("")
print("")
print("              *****************************                   ")
print("              *                           *                   ")
print("              *  welcom too for herM173   *                   ")
print("              *                           *                   ")
print("              *****************************                   ")
print("")
print("")
print("")

import socket , sys
from datetime import datetime
d = input("press D for Domain Name or press I for IP Address:")
if (d=='d' or d=='D'):
    rmserver = input("\Enter the domain to scan: \t")
    rimp = socket.gethostbyname(rmserver)
elif (d=='I' or d=='i'):
    rimp= input("t Enter remote host IP to scan :")
else:
    print('wrong input')
r1=int(input("\t Enter the start port number :\t"))
r2=int(input("\t Enter the last port number :\t"))
print('*'*60)
print('\n port Scanner is working on: ',rimp)
print('*'*60)
print('_'*13)
print('\n Scanning ... |')
print('_'*13)
t1=datetime.now()
try:
    for port in range(r1,r2):
        sock=socket.socket(socket.AF_INET ,socket.SOCK_STREAM)
        socket.setdefaulttimeout(1)
        result=sock.connect_ex((rimp,port))
        if result ==0:
            print('port Open:-->\t',port,"--",socket.getservbyport(port))
        sock.close()
except KeyboardInterrupt:
    print('tou stop this')
    sys.exit()
except socket.gaierror:
    print ('Hostname coluld not be resolver')
    sys.exit()
t2=datetime.now()
total=t2-t1
print('scanning complete in: ',total)
    
